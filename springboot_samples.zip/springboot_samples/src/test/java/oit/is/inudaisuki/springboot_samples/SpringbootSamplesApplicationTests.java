package oit.is.inudaisuki.springboot_samples;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSamplesApplicationTests {

	@Test
	void contextLoads() {
	}

}

package oit.is.inudaisuki.springboot_samples.model;

public class UserInfo {
  String user;
  double height;

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public double getHeight() {
    return height;
  }

  public void setHeight(double height) {
    this.height = height;
  }

}
